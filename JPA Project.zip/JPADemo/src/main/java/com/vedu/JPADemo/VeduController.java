package com.vedu.JPADemo;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.batch.BatchProperties.Job;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.vedu.JPADemo.entities.Account;
import com.vedu.JPADemo.entities.Employee;
import com.vedu.JPADemo.entities.Jobs;
import com.vedu.JPADemo.repositories.AccountRepository;
import com.vedu.JPADemo.repositories.EmpRepository;
import com.vedu.JPADemo.repositories.JobsRepository;

@Controller
public class VeduController 
{
	@Autowired
	private AccountRepository accrepo;
	
	@Autowired
	private EmpRepository emprepo;
	
	@Autowired
	private JobsRepository jrepo;

	@GetMapping("/")
	public String home()
	{
		return "index.jsp";
	}
	
	@GetMapping("/newacc")
	public String newAccount()
	{
		return "NewAccount.jsp";
	}
	
	@PostMapping("/addacc")
	public String addNewAccount(Account obj)
	{
		//System.out.println(obj.getAccnm());
		accrepo.save(obj);
		return "AccountAdded.jsp";
	}
	
	@GetMapping("/newemp")
	public String newEmp()
	{
		return "NewEmployee.jsp";
	}
	
	@PostMapping("/addemp")
	public String AddNewEmp(Employee e)
	{
		/*Employee e=new Employee();
		e.setEmpno(101);
		e.setEmpnm("vedanti");
		e.setDept("IT");
		e.setPost("backend developer");
		e.setLocation("Banglure");
		e.setSalary(120000);*/
		emprepo.save(e);
		return "EmpAdded.jsp";
		
	}
	
	@GetMapping("/allemp")
	public ModelAndView showAllEmp()
	{
		ModelAndView mv= new ModelAndView();
		mv.setViewName("EmpReport.jsp");
		List<Employee> emplist=emprepo.findAll();
		mv.addObject("emplist",emplist);
		return mv;
	}
	
	@GetMapping("/allacc")
	public ModelAndView showAllAcc()
	{
		ModelAndView mv= new ModelAndView();
		mv.setViewName("AccReport.jsp");
		List<Account> acclist=accrepo.findAll();
		mv.addObject("acclist",acclist);
		return mv;
	}
	
	@PostMapping("/searchno")
	public ModelAndView searchNumber(int accno)
	{
		ModelAndView mv= new ModelAndView();
		mv.setViewName("AccReport.jsp");
		Account acc=accrepo.findByAccno(accno);
		System.out.println(acc.getAccnm());
		System.out.println(acc.getBalance());
		
		List<Account> acclist =new ArrayList();
		acclist.add(acc);
		mv.addObject("acclist",acclist);
		
		
		/*List<Account> acctypelist=accrepo.findByAcctype("saving");
		System.out.println(acctypelist.size());*/
		return mv;
		
		
	}
	
	@PostMapping("/searchtype")
	public ModelAndView searchType(String acctype)
	{
		ModelAndView mv= new ModelAndView();
		mv.setViewName("AccReport.jsp");
		List<Account> acclist=accrepo.findByAcctype(acctype);
		mv.addObject("acclist",acclist);
		
		return mv;
		
	}
	
	@PostMapping("/deposit")
	public String depositAmount(int accno,float amount)
	{
		Account obj=accrepo.findByAccno(accno);
		obj.setBalance(obj.getBalance()+amount);
		accrepo.save(obj);
		System.out.println("deposit sucessful");
		return "index.jsp";
	}
	
	@PostMapping("/withdraw")
	public String withdrawAmount(int accno,float amount)
	{
		Account obj=accrepo.findByAccno(accno);
		obj.setBalance(obj.getBalance()-amount);
		accrepo.save(obj);
		System.out.println("withdraw sucessful");
		return "index.jsp";
	}
	
	@GetMapping("/empdelete")
	public String empDelete()
	{
		
		return "EmpDelete.jsp";
	}
	
	@PostMapping("/delemp")
	public String delEmp(int empno)
	{
		Employee e=emprepo.findByEmpno(empno);
		System.out.println(e.getEmpnm());
		emprepo.delete(e);
		return "EmpDeleted.jsp";
	}
	
	@GetMapping("/newjob")
	public String newJob()
	{
		Jobs j = new Jobs();
		j.setCompany("TCS");
		j.setProfile("Data");
		j.setSkills("aws");
		j.setExperience(3);
		jrepo.save(j);
		return "index.jsp";
		
		
	}
	
}
