package com.vedu.JPADemo.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.vedu.JPADemo.entities.Jobs;

public interface JobsRepository extends JpaRepository<Jobs , Integer>
{

}
